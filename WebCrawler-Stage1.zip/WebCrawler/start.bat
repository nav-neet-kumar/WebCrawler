@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 22.12 or newer first.
  pause
  exit /b 1
)
for /f %%v in ('node --version') do set NODE_VERSION=%%v
node -e "const [major,minor]=process.versions.node.split('.').map(Number); if(major<22||(major===22&&minor<12)) process.exit(1)"
if errorlevel 1 (
  echo Detected Node.js version is %NODE_VERSION%. WebCrawler requires Node.js 22.12 or newer.
  pause
  exit /b 1
)
if not exist node_modules\.bin\vite.cmd (
  echo Installing npm dependencies...
  call npm install || goto :error
)
echo Checking Playwright Chromium...
call npx playwright install chromium || goto :error
echo Starting WebCrawler...
call npm run dev
exit /b 0
:error
echo Startup failed. Review the error above.
pause
exit /b 1
