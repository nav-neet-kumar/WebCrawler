export type CrawlStatus = 'queued' | 'running' | 'stopping' | 'completed' | 'stopped' | 'failed';
export type FetchMethod = 'http' | 'playwright' | 'none';
export type AttemptMethod = 'http-fetch' | 'playwright-domcontentloaded' | 'playwright-hydration' | 'playwright-commit';

export interface CrawlOptions {
  startUrl: string;
  maxPages: number;
  maxDepth: number;
  concurrency: number;
}

export interface FetchAttempt {
  method: AttemptMethod;
  outcome: 'success' | 'http-error' | 'network-error' | 'timeout' | 'skipped';
  statusCode?: number;
  durationMs: number;
  message?: string;
}

export interface CrawlPage {
  url: string;
  finalUrl?: string;
  statusCode?: number;
  contentType?: string;
  title?: string;
  description?: string;
  canonical?: string;
  robots?: string;
  h1?: string[];
  wordCount: number;
  internalLinks: number;
  externalLinks: number;
  fetchMethod: FetchMethod;
  attempts: FetchAttempt[];
  fallbackReason?: string;
  depth: number;
  durationMs: number;
  outcome: 'success' | 'http-error' | 'blocked' | 'failed' | 'non-html' | 'redirect';
  error?: string;
  crawledAt: string;
}

export interface CrawlStats {
  discovered: number;
  processed: number;
  succeeded: number;
  failed: number;
  browserFallbacks: number;
  internalLinksFound: number;
  externalLinksFound: number;
}

export interface CrawlLog {
  at: string;
  level: 'info' | 'warn' | 'error';
  message: string;
  url?: string;
}

export interface CrawlJobSnapshot {
  id: string;
  status: CrawlStatus;
  options: CrawlOptions;
  startedAt: string;
  finishedAt?: string;
  stats: CrawlStats;
  pages: CrawlPage[];
  logs: CrawlLog[];
  error?: string;
}
