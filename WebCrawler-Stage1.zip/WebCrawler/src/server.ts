import Fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import { z } from 'zod';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { addLog, createJob, getJob, listJobs, snapshot } from './job-store.js';
import { runCrawl, stopCrawl } from './crawler/crawl-runner.js';
import { assertPublicTarget, validateStartUrl } from './crawler/url-utils.js';

const app = Fastify({ logger: { level: 'info' }, bodyLimit: 64 * 1024 });
const port = Number(process.env.PORT ?? 3001);
const host = process.env.HOST ?? '127.0.0.1';
const currentDir = path.dirname(fileURLToPath(import.meta.url));
const webDist = path.resolve(currentDir, '../web/dist');

const createCrawlSchema = z.object({
  url: z.string().min(1).max(2_048),
  maxPages: z.coerce.number().int().min(1).max(10_000).default(500),
  maxDepth: z.coerce.number().int().min(0).max(20).default(5),
  concurrency: z.coerce.number().int().min(1).max(8).default(3),
});

app.get('/api/health', async () => ({ status: 'ok', app: 'WebCrawler', version: '0.1.0' }));

app.get('/api/crawls', async () => ({ crawls: listJobs() }));

app.post('/api/crawls', async (request, reply) => {
  const parsed = createCrawlSchema.safeParse(request.body);
  if (!parsed.success) {
    return reply.code(400).send({ error: 'Invalid crawl configuration.', details: parsed.error.flatten() });
  }

  let startUrl: string;
  try {
    startUrl = validateStartUrl(parsed.data.url);
    await assertPublicTarget(startUrl);
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : String(cause);
    return reply.code(400).send({ error: message });
  }

  const job = createJob({
    startUrl,
    maxPages: parsed.data.maxPages,
    maxDepth: parsed.data.maxDepth,
    concurrency: parsed.data.concurrency,
  });
  addLog(job, 'info', 'Crawl job accepted by the local API.');
  void runCrawl(job).catch((cause) => {
    job.status = 'failed';
    job.error = cause instanceof Error ? cause.message : String(cause);
    job.finishedAt = new Date().toISOString();
    addLog(job, 'error', `Unexpected crawler failure: ${job.error}`);
  });

  return reply.code(202).send({ crawl: snapshot(job) });
});

app.get<{ Params: { id: string } }>('/api/crawls/:id', async (request, reply) => {
  const job = getJob(request.params.id);
  if (!job) return reply.code(404).send({ error: 'Crawl not found.' });
  return { crawl: snapshot(job) };
});

app.post<{ Params: { id: string } }>('/api/crawls/:id/stop', async (request, reply) => {
  const job = getJob(request.params.id);
  if (!job) return reply.code(404).send({ error: 'Crawl not found.' });
  if (job.status !== 'running') return reply.code(409).send({ error: `Cannot stop a crawl in state ${job.status}.` });
  stopCrawl(job);
  return { crawl: snapshot(job) };
});

if (process.env.NODE_ENV === 'production') {
  await app.register(fastifyStatic, { root: webDist, prefix: '/' });
  app.setNotFoundHandler((request, reply) => {
    if (request.method === 'GET' && !request.url.startsWith('/api/')) {
      return reply.sendFile('index.html');
    }
    return reply.code(404).send({ error: 'Not found.' });
  });
}

try {
  await app.listen({ port, host });
  app.log.info(`WebCrawler API listening at http://${host}:${port}`);
} catch (error) {
  app.log.error(error);
  process.exit(1);
}
