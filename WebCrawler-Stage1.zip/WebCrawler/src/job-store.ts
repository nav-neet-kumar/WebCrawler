import { randomUUID } from 'node:crypto';
import type { BasicCrawler } from 'crawlee';
import type { CrawlJobSnapshot, CrawlLog, CrawlOptions, CrawlPage, CrawlStats } from './types.js';

export interface CrawlJob extends CrawlJobSnapshot {
  crawler?: BasicCrawler;
  knownUrls: Set<string>;
  listeners: Set<() => void>;
}

const jobs = new Map<string, CrawlJob>();

export function createJob(options: CrawlOptions): CrawlJob {
  const id = randomUUID();
  const job: CrawlJob = {
    id,
    status: 'queued',
    options,
    startedAt: new Date().toISOString(),
    stats: emptyStats(),
    pages: [],
    logs: [],
    knownUrls: new Set(),
    listeners: new Set(),
  };
  jobs.set(id, job);
  return job;
}

function emptyStats(): CrawlStats {
  return {
    discovered: 0,
    processed: 0,
    succeeded: 0,
    failed: 0,
    browserFallbacks: 0,
    internalLinksFound: 0,
    externalLinksFound: 0,
  };
}

export function getJob(id: string): CrawlJob | undefined {
  return jobs.get(id);
}

export function addLog(job: CrawlJob, level: CrawlLog['level'], message: string, url?: string): void {
  job.logs.push({ at: new Date().toISOString(), level, message, url });
  if (job.logs.length > 300) job.logs.splice(0, job.logs.length - 300);
  notify(job);
}

export function addPage(job: CrawlJob, page: CrawlPage): void {
  job.pages.push(page);
  job.stats.processed += 1;
  if (page.outcome === 'success') job.stats.succeeded += 1;
  else job.stats.failed += 1;
  if (page.fetchMethod === 'playwright') job.stats.browserFallbacks += 1;
  job.stats.internalLinksFound += page.internalLinks;
  job.stats.externalLinksFound += page.externalLinks;
  notify(job);
}

export function notify(job: CrawlJob): void {
  for (const listener of job.listeners) listener();
}

export function snapshot(job: CrawlJob): CrawlJobSnapshot {
  return {
    id: job.id,
    status: job.status,
    options: job.options,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    stats: { ...job.stats },
    pages: [...job.pages],
    logs: [...job.logs],
    error: job.error,
  };
}

export function listJobs(): CrawlJobSnapshot[] {
  return [...jobs.values()].map(snapshot).sort((a, b) => b.startedAt.localeCompare(a.startedAt));
}
