import { BasicCrawler, RequestQueue } from 'crawlee';
import { chromium, type Browser } from 'playwright';
import path from 'node:path';
import type { CrawlPage, FetchAttempt } from '../types.js';
import { addLog, addPage, notify, type CrawlJob } from '../job-store.js';
import { evaluateHtml, looksLikeClientRenderedShell } from './page-evaluator.js';
import { isSameOrigin, normalizeUrl } from './url-utils.js';

const HTTP_TIMEOUT_MS = 15_000;
const BROWSER_TIMEOUT_MS = 18_000;
const MAX_HTML_BYTES = 4 * 1024 * 1024;

class BrowserFallbackError extends Error {
  constructor(message: string, readonly attempts: FetchAttempt[]) {
    super(message);
    this.name = 'BrowserFallbackError';
  }
}

interface FetchResult {
  html: string;
  finalUrl: string;
  statusCode: number;
  contentType?: string;
}

interface BrowserResult extends FetchResult {
  attempts: FetchAttempt[];
  blockedReason?: string;
}

async function readTextLimited(response: Response): Promise<string> {
  if (!response.body) return '';
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let received = 0;
  let output = '';
  try {
    while (received < MAX_HTML_BYTES) {
      const { done, value } = await reader.read();
      if (done) break;
      const remaining = MAX_HTML_BYTES - received;
      const chunk = value.subarray(0, remaining);
      output += decoder.decode(chunk, { stream: true });
      received += chunk.byteLength;
      if (chunk.byteLength < value.byteLength) break;
    }
    output += decoder.decode();
  } finally {
    await reader.cancel().catch(() => undefined);
  }
  return output;
}

async function fetchOverHttp(url: string): Promise<{ result?: FetchResult; attempt: FetchAttempt; error?: Error }> {
  const started = Date.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const originalOrigin = new URL(url).origin;
    let currentUrl = url;
    let response: Response | undefined;
    let crossOriginRedirect: string | undefined;
    for (let redirectCount = 0; redirectCount <= 5; redirectCount += 1) {
      response = await fetch(currentUrl, {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5',
        },
      });
      const location = response.headers.get('location');
      if (response.status < 300 || response.status >= 400 || !location) break;
      const nextUrl = normalizeUrl(location, currentUrl);
      if (!nextUrl) break;
      if (new URL(nextUrl).origin !== originalOrigin) {
        crossOriginRedirect = nextUrl;
        break;
      }
      if (redirectCount === 5) break;
      await response.body?.cancel().catch(() => undefined);
      currentUrl = nextUrl;
    }
    if (!response) throw new Error('No HTTP response was returned.');
    const contentType = response.headers.get('content-type') ?? undefined;
    const body = await readTextLimited(response);
    return {
      result: {
        html: body,
        finalUrl: currentUrl,
        statusCode: response.status,
        contentType,
      },
      attempt: {
        method: 'http-fetch',
        outcome: response.ok ? 'success' : 'http-error',
        statusCode: response.status,
        durationMs: Date.now() - started,
        message: crossOriginRedirect ? `Cross-origin redirect was not followed: ${crossOriginRedirect}` : response.ok ? undefined : `HTTP ${response.status}`,
      },
    };
  } catch (cause) {
    const error = cause instanceof Error ? cause : new Error(String(cause));
    const isTimeout = error.name === 'AbortError';
    return {
      error,
      attempt: {
        method: 'http-fetch',
        outcome: isTimeout ? 'timeout' : 'network-error',
        durationMs: Date.now() - started,
        message: error.message,
      },
    };
  } finally {
    clearTimeout(timeout);
  }
}

function containsAccessChallenge(html: string): boolean {
  return /captcha|verify you are human|checking your browser|security challenge|unusual traffic/i.test(html.slice(0, 100_000));
}

async function fetchWithBrowser(url: string, browser: Browser): Promise<BrowserResult> {
  const attempts: FetchAttempt[] = [];
  const page = await browser.newPage();
  page.setDefaultNavigationTimeout(BROWSER_TIMEOUT_MS);
  page.setDefaultTimeout(5_000);
  const originalOrigin = new URL(url).origin;
  try {
    await page.route('**/*', async (route) => {
      const request = route.request();
      try {
        if (request.isNavigationRequest() && request.frame() === page.mainFrame() && new URL(request.url()).origin !== originalOrigin) {
          await route.abort();
          return;
        }
      } catch {
        await route.abort();
        return;
      }
      await route.continue();
    });
    const firstStarted = Date.now();
    try {
      const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: BROWSER_TIMEOUT_MS });
      const html = await page.content();
      const statusCode = response?.status() ?? 0;
      attempts.push({
        method: 'playwright-domcontentloaded',
        outcome: statusCode >= 400 ? 'http-error' : 'success',
        statusCode: statusCode || undefined,
        durationMs: Date.now() - firstStarted,
        message: statusCode >= 400 ? `Browser returned HTTP ${statusCode}` : undefined,
      });
      const contentType = response?.headers()['content-type'];
      const challenge = containsAccessChallenge(html);
      if (statusCode === 429 || statusCode === 401 || statusCode === 403 || challenge) {
        return {
          html,
          finalUrl: page.url() || url,
          statusCode: statusCode || 403,
          contentType,
          attempts,
          blockedReason: challenge ? 'An access challenge or CAPTCHA was detected. No challenge-solving or evasion was attempted.' : `Browser access returned HTTP ${statusCode}.`,
        };
      }
      if (!looksLikeClientRenderedShell(html)) {
        return { html, finalUrl: page.url() || url, statusCode: statusCode || 200, contentType, attempts };
      }

      // Some client-rendered pages hydrate shortly after DOMContentLoaded.
      await page.waitForFunction(() => document.readyState === 'complete', undefined, { timeout: 4_000 }).catch(() => undefined);
      await page.waitForTimeout(900);
      const hydratedHtml = await page.content();
      if (!looksLikeClientRenderedShell(hydratedHtml)) {
        attempts.push({
          method: 'playwright-hydration',
          outcome: 'success',
          statusCode: statusCode || undefined,
          durationMs: Date.now() - firstStarted,
          message: 'Content became available after browser hydration wait.',
        });
        return { html: hydratedHtml, finalUrl: page.url() || url, statusCode: statusCode || 200, contentType, attempts };
      }
    } catch (cause) {
      const error = cause instanceof Error ? cause : new Error(String(cause));
      attempts.push({
        method: 'playwright-domcontentloaded',
        outcome: error.name === 'TimeoutError' ? 'timeout' : 'network-error',
        durationMs: Date.now() - firstStarted,
        message: error.message,
      });
    }

    // A second, less restrictive navigation wait can succeed when the page never fires DOMContentLoaded.
    const secondStarted = Date.now();
    try {
      const response = await page.goto(url, { waitUntil: 'commit', timeout: BROWSER_TIMEOUT_MS });
      await page.locator('body').waitFor({ state: 'attached', timeout: 4_000 }).catch(() => undefined);
      await page.waitForTimeout(1_000);
      const html = await page.content().catch(() => '');
      const statusCode = response?.status() ?? 0;
      attempts.push({
        method: 'playwright-commit',
        outcome: statusCode >= 400 ? 'http-error' : 'success',
        statusCode: statusCode || undefined,
        durationMs: Date.now() - secondStarted,
        message: statusCode >= 400 ? `Browser returned HTTP ${statusCode}` : 'Loaded using commit navigation and inspected the resulting DOM.',
      });
      const challenge = containsAccessChallenge(html);
      if (statusCode === 429 || statusCode === 401 || statusCode === 403 || challenge) {
        return {
          html,
          finalUrl: page.url() || url,
          statusCode: statusCode || 403,
          contentType: response?.headers()['content-type'],
          attempts,
          blockedReason: challenge ? 'An access challenge or CAPTCHA was detected. No challenge-solving or evasion was attempted.' : `Browser access returned HTTP ${statusCode}.`,
        };
      }
      return {
        html,
        finalUrl: page.url() || url,
        statusCode: statusCode || 200,
        contentType: response?.headers()['content-type'],
        attempts,
      };
    } catch (cause) {
      const error = cause instanceof Error ? cause : new Error(String(cause));
      attempts.push({
        method: 'playwright-commit',
        outcome: error.name === 'TimeoutError' ? 'timeout' : 'network-error',
        durationMs: Date.now() - secondStarted,
        message: error.message,
      });
      throw new BrowserFallbackError(`Browser fallback failed: ${error.message}`, attempts);
    }
  } finally {
    await page.close().catch(() => undefined);
  }
}

function failedPage(input: {
  url: string;
  depth: number;
  attempts: FetchAttempt[];
  durationMs: number;
  error: string;
  fallbackReason?: string;
}): CrawlPage {
  return {
    url: input.url,
    wordCount: 0,
    internalLinks: 0,
    externalLinks: 0,
    fetchMethod: 'none',
    attempts: input.attempts,
    fallbackReason: input.fallbackReason,
    depth: input.depth,
    durationMs: input.durationMs,
    outcome: 'failed',
    error: input.error,
    crawledAt: new Date().toISOString(),
  };
}

export async function runCrawl(job: CrawlJob): Promise<void> {
  const { options } = job;
  process.env.CRAWLEE_STORAGE_DIR ??= path.resolve(process.cwd(), 'data/crawlee');
  const queueName = `webcrawler-${job.id}`;
  const requestQueue = await RequestQueue.open(queueName);
  let browser: Browser | undefined;
  const origin = new URL(options.startUrl).origin;

  job.status = 'running';
  job.stats.discovered = 1;
  job.knownUrls.add(options.startUrl);
  addLog(job, 'info', `Started hybrid crawl for ${options.startUrl}`);
  addLog(job, 'info', `Scope: same origin (${origin}); maximum ${options.maxPages} pages; depth ${options.maxDepth}.`);

  await requestQueue.addRequest({
    url: options.startUrl,
    uniqueKey: options.startUrl,
    userData: { depth: 0 },
  });

  const crawler = new BasicCrawler({
    requestQueue,
    maxConcurrency: options.concurrency,
    maxRequestRetries: 0,
    requestHandlerTimeoutSecs: 70,
    respectRobotsTxtFile: true,
    requestHandler: async ({ request }) => {
      const started = Date.now();
      const url = request.url;
      const depth = typeof request.userData.depth === 'number' ? request.userData.depth : 0;
      const attempts: FetchAttempt[] = [];
      let fallbackReason: string | undefined;
      addLog(job, 'info', 'Fetching page', url);

      const direct = await fetchOverHttp(url);
      attempts.push(direct.attempt);

      let selected: FetchResult | undefined = direct.result;
      let method: 'http' | 'playwright' | 'none' = 'http';
      let failureMessage: string | undefined;
      let shouldFallback = false;
      const directContentType = direct.result?.contentType?.toLowerCase() ?? '';
      const directIsHtml = directContentType.includes('text/html') || directContentType.includes('application/xhtml+xml') || directContentType === '';
      const directChallengeDetected = direct.result !== undefined && directIsHtml && containsAccessChallenge(direct.result.html);
      let blockedByChallenge = false;

      if (direct.error) {
        shouldFallback = true;
        fallbackReason = 'Direct HTTP request failed; trying a standard browser navigation.';
        failureMessage = direct.error.message;
      } else if (direct.result) {
        const status = direct.result.statusCode;
        const contentType = direct.result.contentType?.toLowerCase() ?? '';
        const htmlResponse = contentType.includes('text/html') || contentType.includes('application/xhtml+xml') || contentType === '';
        if (status !== 429 && status >= 400) {
          shouldFallback = true;
          fallbackReason = `Direct HTTP returned ${status}; evaluating the same public URL with a standard browser.`;
        } else if (status !== 429 && directChallengeDetected) {
          shouldFallback = true;
          fallbackReason = 'Direct HTTP response resembles an access challenge; checking once with a standard browser.';
        } else if (status !== 429 && htmlResponse && looksLikeClientRenderedShell(direct.result.html)) {
          shouldFallback = true;
          fallbackReason = 'HTTP response looks like a JavaScript shell; trying browser rendering.';
        }
      }

      if (direct.result?.statusCode === 429) {
        fallbackReason = 'HTTP 429 rate limit detected; browser retry was intentionally skipped to avoid increasing load.';
        addLog(job, 'warn', 'Rate limited (429); no immediate retry attempted.', url);
      }

      if (shouldFallback) {
        addLog(job, 'warn', fallbackReason ?? 'Switching to browser fallback.', url);
        try {
          browser ??= await chromium.launch({ headless: true });
          const browserResult = await fetchWithBrowser(url, browser);
          attempts.push(...browserResult.attempts);
          selected = browserResult;
          method = 'playwright';
          if (browserResult.blockedReason) {
            failureMessage = browserResult.blockedReason;
            blockedByChallenge = true;
            addLog(job, 'warn', browserResult.blockedReason, url);
          } else {
            addLog(job, 'info', 'Browser fallback returned a page for evaluation.', url);
          }
        } catch (cause) {
          failureMessage = cause instanceof Error ? cause.message : String(cause);
          blockedByChallenge = directChallengeDetected;
          if (cause instanceof BrowserFallbackError) {
            attempts.push(...cause.attempts);
          } else {
            attempts.push({
              method: 'playwright-domcontentloaded',
              outcome: 'network-error',
              durationMs: 0,
              message: failureMessage,
            });
          }
          addLog(job, 'error', `All available fetch methods failed: ${failureMessage}`, url);
        }
      }

      let page: CrawlPage;
      let links: Array<{ url: string; isInternal: boolean }> = [];

      if (selected) {
        const evaluated = evaluateHtml({
          requestedUrl: url,
          finalUrl: selected.finalUrl,
          html: selected.html,
          statusCode: selected.statusCode,
          contentType: selected.contentType,
          method,
          attempts,
          depth,
          durationMs: Date.now() - started,
          fallbackReason,
        });
        page = evaluated.page;
        links = evaluated.links;
        if (blockedByChallenge) {
          page.outcome = 'blocked';
          page.error = failureMessage ?? 'An access challenge was detected; no challenge-solving or evasion was attempted.';
          links = [];
        } else if (failureMessage && page.outcome !== 'success') {
          page.error = failureMessage;
        }
        if (selected.contentType && !/html|xhtml/i.test(selected.contentType) && method === 'http') {
          addLog(job, 'info', `Non-HTML resource recorded (${selected.contentType}).`, url);
        } else if (page.outcome === 'success') {
          addLog(job, 'info', `Evaluated: HTTP ${page.statusCode ?? 'n/a'}, ${links.length} links, ${page.wordCount} words, via ${page.fetchMethod}.`, url);
        } else {
          addLog(job, 'warn', `Page evaluated with outcome: ${page.outcome}.`, url);
        }
      } else {
        page = failedPage({
          url,
          depth,
          attempts,
          durationMs: Date.now() - started,
          error: failureMessage ?? 'No fetch method returned a page.',
          fallbackReason,
        });
      }

      addPage(job, page);

      if (depth >= options.maxDepth || page.outcome === 'blocked' || page.outcome === 'failed') return;
      for (const link of links) {
        if (!link.isInternal || !isSameOrigin(link.url, origin)) continue;
        const normalized = normalizeUrl(link.url);
        if (!normalized || job.knownUrls.has(normalized)) continue;
        if (job.knownUrls.size >= options.maxPages) break;
        job.knownUrls.add(normalized);
        const result = await requestQueue.addRequest({
          url: normalized,
          uniqueKey: normalized,
          userData: { depth: depth + 1 },
        });
        if (!result.wasAlreadyPresent) {
          job.stats.discovered += 1;
        }
      }
      notify(job);
    },
    failedRequestHandler: async ({ request }, error) => {
      const depth = typeof request.userData.depth === 'number' ? request.userData.depth : 0;
      addPage(job, failedPage({
        url: request.url,
        depth,
        attempts: [],
        durationMs: 0,
        error: error.message,
      }));
      addLog(job, 'error', `Crawler request failed: ${error.message}`, request.url);
    },
  });

  job.crawler = crawler;
  notify(job);

  try {
    await crawler.run();
    if (job.status === 'stopping') {
      job.status = 'stopped';
      addLog(job, 'warn', 'Crawl stopped by user.');
    } else {
      job.status = 'completed';
      addLog(job, 'info', 'Crawl completed.');
    }
  } catch (cause) {
    job.status = 'failed';
    job.error = cause instanceof Error ? cause.message : String(cause);
    addLog(job, 'error', `Crawl failed: ${job.error}`);
  } finally {
    job.finishedAt = new Date().toISOString();
    job.crawler = undefined;
    if (browser) await browser.close().catch(() => undefined);
    await requestQueue.drop().catch(() => undefined);
    notify(job);
  }
}

export function stopCrawl(job: CrawlJob): void {
  if (job.status !== 'running') return;
  job.status = 'stopping';
  addLog(job, 'warn', 'Stop requested; active page evaluations will finish before the crawler exits.');
  job.crawler?.stop();
  notify(job);
}
