import * as cheerio from 'cheerio';
import type { CrawlPage, FetchAttempt, FetchMethod } from '../types.js';
import { isSameOrigin, normalizeUrl } from './url-utils.js';

export interface ParsedPage {
  page: Omit<CrawlPage, 'url' | 'depth' | 'durationMs' | 'crawledAt' | 'attempts' | 'fetchMethod' | 'fallbackReason'>;
  links: Array<{ url: string; isInternal: boolean }>;
  html: string;
}

export function evaluateHtml(input: {
  requestedUrl: string;
  finalUrl: string;
  html: string;
  statusCode?: number;
  contentType?: string;
  method: FetchMethod;
  attempts: FetchAttempt[];
  depth: number;
  durationMs: number;
  fallbackReason?: string;
}): { page: CrawlPage; links: Array<{ url: string; isInternal: boolean }> } {
  const $ = cheerio.load(input.html);
  const finalUrl = input.finalUrl || input.requestedUrl;
  const origin = new URL(input.requestedUrl).origin;
  const rawLinks = new Map<string, boolean>();

  $('a[href]').each((_index, element) => {
    const href = $(element).attr('href');
    if (!href) return;
    const normalized = normalizeUrl(href, finalUrl);
    if (!normalized) return;
    rawLinks.set(normalized, isSameOrigin(normalized, origin));
  });

  const bodyText = $('body').text().replace(/\s+/g, ' ').trim();
  const words = bodyText ? bodyText.split(' ').filter(Boolean).length : 0;
  const statusCode = input.statusCode;
  const isBlocked = statusCode === 401 || statusCode === 403 || statusCode === 429;
  const isSuccess = statusCode !== undefined && statusCode >= 200 && statusCode < 300;
  const isRedirect = statusCode !== undefined && statusCode >= 300 && statusCode < 400;
  const contentType = input.contentType?.split(';')[0]?.trim();
  const isHtml = !contentType || contentType === 'text/html' || contentType === 'application/xhtml+xml';

  const page: CrawlPage = {
    url: input.requestedUrl,
    finalUrl,
    statusCode,
    contentType,
    title: $('title').first().text().trim() || undefined,
    description: $('meta[name="description"]')?.attr('content')?.trim() || undefined,
    canonical: $('link[rel="canonical"]')?.attr('href')?.trim() || undefined,
    robots: $('meta[name="robots"]')?.attr('content')?.trim() || undefined,
    h1: $('h1').map((_i, el) => $(el).text().replace(/\s+/g, ' ').trim()).get().filter(Boolean),
    wordCount: words,
    internalLinks: [...rawLinks.values()].filter(Boolean).length,
    externalLinks: [...rawLinks.values()].filter((value) => !value).length,
    fetchMethod: input.method,
    attempts: input.attempts,
    fallbackReason: input.fallbackReason,
    depth: input.depth,
    durationMs: input.durationMs,
    outcome: isBlocked ? 'blocked' : isRedirect ? 'redirect' : isSuccess ? (isHtml ? 'success' : 'non-html') : 'http-error',
    error: isBlocked ? `Access or traffic protection response (${statusCode}). The crawler records this response and does not attempt to defeat it.` : isRedirect ? `Redirect response (${statusCode}) was recorded; its destination was not fetched in Stage 1.` : undefined,
    crawledAt: new Date().toISOString(),
  };

  return { page, links: [...rawLinks.entries()].map(([url, isInternal]) => ({ url, isInternal })) };
}

export function looksLikeClientRenderedShell(html: string): boolean {
  const $ = cheerio.load(html);
  const bodyText = $('body').text().replace(/\s+/g, ' ').trim();
  const anchorCount = $('a[href]').length;
  const scriptCount = $('script[src]').length;
  const hasAppRoot = $('#root, #app, #__next, #__nuxt, [data-reactroot]').length > 0;
  return bodyText.length < 220 && anchorCount < 2 && (scriptCount > 0 || hasAppRoot);
}
