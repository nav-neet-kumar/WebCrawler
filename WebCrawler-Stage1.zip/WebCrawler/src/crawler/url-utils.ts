import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';

const TRACKING_PARAMS = new Set(['fbclid', 'gclid', 'dclid', 'mc_cid', 'mc_eid']);

export function normalizeUrl(input: string, base?: string): string | null {
  try {
    const url = base ? new URL(input, base) : new URL(input);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
    url.hash = '';
    url.hostname = url.hostname.toLowerCase();
    if ((url.protocol === 'http:' && url.port === '80') || (url.protocol === 'https:' && url.port === '443')) {
      url.port = '';
    }
    for (const key of [...url.searchParams.keys()]) {
      if (TRACKING_PARAMS.has(key.toLowerCase())) url.searchParams.delete(key);
    }
    url.searchParams.sort();
    return url.toString();
  } catch {
    return null;
  }
}

export function isSameOrigin(candidate: string, origin: string): boolean {
  try {
    return new URL(candidate).origin === origin;
  } catch {
    return false;
  }
}

export function validateStartUrl(input: string): string {
  const normalized = normalizeUrl(input);
  if (!normalized) throw new Error('Enter a valid HTTP or HTTPS URL.');
  const parsed = new URL(normalized);
  if (parsed.username || parsed.password) throw new Error('URLs containing embedded credentials are not supported.');
  if (parsed.hostname === 'localhost' || parsed.hostname.endsWith('.localhost') || parsed.hostname === '::1' || parsed.hostname.startsWith('127.')) {
    throw new Error('Localhost targets are disabled in this release. Use a public website URL.');
  }
  return normalized;
}

function isPrivateIPv4(address: string): boolean {
  const parts = address.split('.').map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return true;
  const [a, b] = parts as [number, number, number, number];
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 0 || b === 168)) ||
    (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19));
}

function isPrivateIPv6(address: string): boolean {
  const value = address.toLowerCase();
  return value === '::' || value === '::1' || value.startsWith('fc') || value.startsWith('fd') ||
    value.startsWith('fe8') || value.startsWith('fe9') || value.startsWith('fea') || value.startsWith('feb') ||
    value.startsWith('::ffff:127.') || value.startsWith('::ffff:10.') || value.startsWith('::ffff:192.168.') ||
    value.startsWith('::ffff:169.254.') || /^::ffff:172\.(1[6-9]|2[0-9]|3[01])\./.test(value);
}

export async function assertPublicTarget(urlInput: string): Promise<void> {
  const url = new URL(urlInput);
  const hostname = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (hostname === 'localhost' || hostname.endsWith('.localhost') || hostname.endsWith('.local')) {
    throw new Error('Local and .local network targets are disabled in Stage 1.');
  }

  const ipVersion = isIP(hostname);
  if (ipVersion === 4 && isPrivateIPv4(hostname)) throw new Error('Private or reserved IP addresses are blocked in Stage 1.');
  if (ipVersion === 6 && isPrivateIPv6(hostname)) throw new Error('Private or reserved IP addresses are blocked in Stage 1.');
  if (ipVersion === 0) {
    const addresses = await lookup(hostname, { all: true, verbatim: true });
    if (addresses.length === 0) throw new Error('The hostname did not resolve to an IP address.');
    for (const entry of addresses) {
      const privateAddress = entry.family === 4 ? isPrivateIPv4(entry.address) : isPrivateIPv6(entry.address);
      if (privateAddress) throw new Error('The hostname resolves to a private or reserved IP address and is blocked in Stage 1.');
    }
  }
}
