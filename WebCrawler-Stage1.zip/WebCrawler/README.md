# WebCrawler

A local-first hybrid website crawler for website discovery, content inventory and future technical/SEO analysis.

**Current release:** `0.1.0` — Stage 1 foundation  
**Runtime:** Node.js 22.12+  
**Deployment:** Local Windows machine  
**Crawl strategy:** HTTP first, standard Playwright browser fallback

## Stage 1 features

- Local dashboard and Fastify API.
- Recursive same-origin URL discovery.
- URL normalisation and de-duplication.
- Configurable maximum pages, depth and concurrency.
- `robots.txt` respected by default.
- Direct HTTP fetch before browser fallback.
- Playwright fallback for network errors, selected HTTP failures and JavaScript shells.
- A second browser navigation strategy (`commit`) if the first navigation wait fails.
- Page title, description, canonical, robots meta, H1, word count and link extraction.
- Per-page method/attempt history, fallback reason, status and duration.
- Live crawl counters, activity log and graceful stop.

## Requirements

- Windows 10/11 (64-bit)
- Node.js 22.12 or newer
- npm
- Internet connection for the initial dependency and Chromium installation

## Run on Windows

1. Extract this folder.
2. Open PowerShell or Command Prompt in the `WebCrawler` folder.
3. Install dependencies:

   ```powershell
   npm install
   npx playwright install chromium
   ```

4. Start the development application:

   ```powershell
   npm run dev
   ```

5. Open the local dashboard at `http://127.0.0.1:5173`.

The API listens on `http://127.0.0.1:3001`. Both services bind to loopback only.

### Production-style local run

```powershell
npm run build
$env:NODE_ENV="production"
npm start
```

Then open `http://127.0.0.1:3001`.

## Verify the project

```powershell
npm run check
npm test
```

## Fallback behaviour

1. Every page is attempted with direct HTTP first.
2. If HTTP fails at the network layer, returns selected access/server errors, or returns a probable JavaScript shell, the crawler tries a normal Playwright Chromium navigation.
3. If the browser's DOMContentLoaded wait fails or the page remains a shell, it tries a less restrictive `commit` navigation and inspects the resulting DOM.
4. Each attempt is retained in the results table and page detail.
5. A 429 is recorded without immediate retry. CAPTCHA/security challenges and denied access are reported rather than bypassed.

The crawler does not use proxy rotation, stealth plugins, CAPTCHA solving, credential guessing or access-control bypass. Use it only on websites you own or are authorised to inspect.

## Stage boundaries

This is Stage 1, not the complete crawler. Durable crawl history/resume, sitemap discovery, broad asset extraction, exports, SEO audits and visual analytics are explicitly planned for later stages. See [`docs/TECHNICAL_SPEC.md`](docs/TECHNICAL_SPEC.md) for the complete specification and 12-stage roadmap.

## Notes

- The first release limits discovery to the exact starting origin.
- External hyperlinks are counted but not crawled.
- Private/reserved IP and localhost targets are blocked in Stage 1.
- The default crawl cap is 500 pages; hard cap is 10,000.
- Results are currently held in memory and disappear when the API process restarts.
- Node dependencies and Chromium are installed locally; no external scraping API is required.
