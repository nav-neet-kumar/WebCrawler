import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assertPublicTarget, normalizeUrl, isSameOrigin, validateStartUrl } from '../src/crawler/url-utils.js';
import { evaluateHtml, looksLikeClientRenderedShell } from '../src/crawler/page-evaluator.js';

test('normalizes URLs and removes fragments and common tracking parameters', () => {
  assert.equal(
    normalizeUrl('HTTPS://Example.COM:443/docs/page?ref=home&gclid=abc#section'),
    'https://example.com/docs/page?ref=home',
  );
});

test('resolves relative links and rejects non-web protocols', () => {
  assert.equal(normalizeUrl('../guide', 'https://example.com/docs/start'), 'https://example.com/guide');
  assert.equal(normalizeUrl('javascript:void(0)', 'https://example.com/'), null);
  assert.equal(normalizeUrl('mailto:hello@example.com'), null);
});

test('same-origin scope is strict', () => {
  assert.equal(isSameOrigin('https://example.com/a', 'https://example.com'), true);
  assert.equal(isSameOrigin('https://www.example.com/a', 'https://example.com'), false);
  assert.equal(isSameOrigin('http://example.com/a', 'https://example.com'), false);
});

test('rejects embedded credentials and non-http schemes', () => {
  assert.throws(() => validateStartUrl('ftp://example.com/file'));
  assert.throws(() => validateStartUrl('https://user:pass@example.com/'));
});

test('extracts metadata, word count and internal/external links', () => {
  const { page, links } = evaluateHtml({
    requestedUrl: 'https://example.com/',
    finalUrl: 'https://example.com/',
    html: '<html><head><title>Example title</title><meta name="description" content="Demo"></head><body><h1>Hello</h1><p>alpha beta gamma</p><a href="/about">About</a><a href="https://other.example/path">External</a></body></html>',
    statusCode: 200,
    contentType: 'text/html; charset=utf-8',
    method: 'http',
    attempts: [],
    depth: 0,
    durationMs: 12,
  });
  assert.equal(page.title, 'Example title');
  assert.equal(page.description, 'Demo');
  assert.equal(page.wordCount, 6);
  assert.equal(page.internalLinks, 1);
  assert.equal(page.externalLinks, 1);
  assert.equal(links.length, 2);
});

test('detects a likely JavaScript shell but not a populated page', () => {
  assert.equal(looksLikeClientRenderedShell('<html><body><div id="root"></div><script src="/app.js"></script></body></html>'), true);
  assert.equal(looksLikeClientRenderedShell('<html><body><h1>Readable content</h1><p>This page has text content.</p><a href="/one">One</a><a href="/two">Two</a></body></html>'), false);
});


test('blocks localhost and private network targets', async () => {
  await assert.rejects(() => assertPublicTarget('http://192.168.1.10/'));
  await assert.rejects(() => assertPublicTarget('http://127.0.0.1/'));
  await assert.rejects(() => assertPublicTarget('http://[::1]/'));
});
