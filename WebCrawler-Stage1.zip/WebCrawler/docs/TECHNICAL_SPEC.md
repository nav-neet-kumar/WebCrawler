# WebCrawler — Initial Technical Specification

**Product:** WebCrawler  
**Release:** 0.1.0 — Stage 1 foundation  
**Deployment:** Local Windows application (browser UI on localhost)  
**Purpose:** General-purpose website discovery, content inventory and future technical/SEO analysis  
**Crawl strategy:** Hybrid — direct HTTP first, standard Playwright browser fallback when needed

## 1. Product objective

Build a local-first crawler that discovers and evaluates pages reachable from a supplied website URL. It should collect the page response, basic content metadata and link relationships, while recording which fetch mechanisms were attempted and why a fallback occurred.

The crawler is not an indexer and cannot discover an unlinked URL without another source (for example, a sitemap, an imported URL list, server logs or an external link source). A page absent from Google Search is not necessarily inaccessible to this crawler. Access-denied and rate-limited responses are recorded distinctly; access controls and CAPTCHA challenges are not defeated.

## 2. Architecture

```text
React + Vite dashboard (127.0.0.1:5173 in development)
             │ HTTP / JSON
             ▼
Fastify local API (127.0.0.1:3001)
             │
             ▼
Crawlee BasicCrawler + RequestQueue
             │
       ┌─────┴────────┐
       ▼              ▼
 HTTP fetch       Playwright / Chromium
 Cheerio parse    DOM extraction (fallback)
       └─────┬────────┘
             ▼
 In-memory crawl result model
             │
             ▼
 Dashboard table + activity log
```

### Runtime

- Node.js 22.12 or newer.
- TypeScript with strict checking.
- Fastify API bound to loopback only (`127.0.0.1`).
- React/Vite frontend; Vite proxies `/api` to Fastify during development.
- Crawlee manages request scheduling and de-duplication.
- Native Node `fetch` is the initial HTTP transport; Cheerio parses returned HTML.
- Playwright launches Chromium only when the HTTP response fails or appears to be an unhydrated JavaScript shell.
- Stage 1 keeps results in memory. The Crawlee queue is created per job and cleaned up when the job completes; durable crawl history/resume belongs to Stage 3.

## 3. Stage 1 functional requirements

1. Accept a starting HTTP/HTTPS URL.
2. Configure maximum discovered pages, maximum link depth and worker concurrency.
3. Restrict discovery to the exact starting origin.
4. Normalize URLs and remove fragments; de-duplicate by normalized URL.
5. Respect `robots.txt` by default.
6. Fetch HTML directly over HTTP first.
7. Detect a likely JavaScript shell and use Playwright when appropriate.
8. Use a second browser navigation wait (`commit`) if the first navigation strategy fails.
9. Record every attempt, response status, duration, method, fallback reason and final outcome.
10. Extract title, description, canonical, robots meta, H1s, text word count, and internal/external links.
11. Display discovered/evaluated/success/error/fallback counts and a live activity log.
12. Stop a running crawl gracefully.

## 4. Fallback and evaluation policy

A fallback is not considered a success merely because another request was made. Every attempt is stored; the resulting response is evaluated and classified.

| Order | Mechanism | When it runs | What it can establish |
|---|---|---|---|
| 1 | Direct HTTP fetch | First attempt for every page | Status, headers, HTML, redirects within the same origin |
| 2 | Playwright `domcontentloaded` | Network/HTTP failure (except 429), 401/403/5xx, or probable JS shell | Standard browser response and rendered DOM |
| 3 | Browser hydration wait | The browser returns a thin shell | Whether client-side hydration populates the DOM |
| 4 | Playwright `commit` navigation | First browser navigation fails or remains a shell | Whether the response can be inspected with a less restrictive navigation wait |
| 5 | Alternate discovery sources | Stage 2 | Sitemaps and other URL inventories, independent of page navigation |
| 6 | Explicit authorised session | Stage 9 | User-authorised authenticated pages; no credential guessing or challenge solving |

### Fallback rules

- HTTP `429` is recorded as rate-limited and is not immediately retried through the browser, to avoid increasing load.
- A `401`, `403`, or detected CAPTCHA/security challenge is recorded. A normal browser attempt may be evaluated where appropriate, but no CAPTCHA solving, stealth fingerprinting, proxy rotation, credential guessing or access-control bypass is implemented.
- HTTP failures that still return HTML may be recorded as error pages, with the status and attempts preserved.
- Browser navigation uses `domcontentloaded` and `commit`; it does not wait on `networkidle` because that can hang on pages with persistent network activity.
- Main-frame cross-origin redirects are not followed in Stage 1. External hyperlinks are counted but not crawled.
- A page result includes `fetchMethod`, `attempts[]`, `fallbackReason`, `outcome` and `error` so coverage and failure causes are inspectable.

## 5. Initial data contract

Each evaluated page stores:

- `url`, `finalUrl`, `statusCode`, `contentType`
- `title`, `description`, `canonical`, `robots`, `h1[]`
- `wordCount`, `internalLinks`, `externalLinks`, `depth`
- `fetchMethod`: `http`, `playwright` or `none`
- `attempts[]`: method, outcome, status, duration and message
- `fallbackReason`, `durationMs`, `outcome`, `error`, `crawledAt`

Each crawl stores options, lifecycle state, timestamps, aggregate counters, page rows and a bounded activity log.

## 6. Safety, scope and resource limits

- Local API binds to loopback, not `0.0.0.0`.
- Stage 1 rejects localhost, `.local`, private and reserved IP destinations. DNS results are checked at job creation. This is a first-layer SSRF defence, not a substitute for hardened egress controls in a future hosted deployment.
- Crawl scope is exact-origin only; cross-origin links are measured but not enqueued.
- Main-frame cross-origin redirects are blocked.
- The default cap is 500 pages; hard cap is 10,000.
- Concurrency defaults to 3 and is capped at 8.
- HTTP response body processing is capped at 4 MiB per page.
- `robots.txt` is respected.
- Users must crawl websites they own or are authorised to inspect, and configure responsible rate/concurrency settings.

## 7. API surface in Stage 1

- `GET /api/health` — local API health.
- `GET /api/crawls` — recent in-memory crawl list.
- `POST /api/crawls` — validate and start a crawl.
- `GET /api/crawls/:id` — crawl status, metrics, pages and logs.
- `POST /api/crawls/:id/stop` — gracefully stop a crawl.

## 8. Explicit Stage 1 non-goals

- Durable result database and resume after process restart.
- XML sitemap and sitemap-index discovery.
- Subdomain or multi-domain crawling.
- Asset inventory (images, CSS, JavaScript, PDFs).
- SEO auditing, duplicate-content analysis and canonical/redirect issue reports.
- CSV, JSON or XLSX export.
- Crawl visualisations and architecture graphs.
- Login profiles, authenticated sessions, scheduled jobs or cloud workers.
- Proxy rotation, stealth mode, CAPTCHA solving or bypass of access controls.

## 9. Acceptance criteria

Stage 1 is accepted when:

1. `npm run check` passes with no TypeScript errors.
2. `npm test` passes.
3. `npm run dev` starts the API and web dashboard locally.
4. A public test site can be crawled and internal links are discovered without duplicate processing.
5. A likely JavaScript shell triggers a Playwright fallback.
6. Each page clearly shows its attempted methods and the reason for fallback.
7. A `429` is recorded without immediate retries.
8. Crawl depth/page limits and exact-origin scope are enforced.
9. The user can stop an active crawl.

## 10. Twelve-stage delivery roadmap

| Stage | Scope | Exit deliverable |
|---|---|---|
| 1 | Core hybrid crawler: HTTP-first, Playwright fallback, same-origin links, limits, live status | Working local crawl prototype |
| 2 | Discovery expansion: `robots.txt` diagnostics, XML sitemap/index parsing, canonical hints, imported URL list, optional subdomains | Multi-source URL discovery |
| 3 | Durable jobs: SQLite schema, persisted request queue/results, stop/resume/recovery, crawl history | Resumable crawl jobs |
| 4 | Results explorer: searchable/sortable/filterable page table, detailed page inspector, response/attempt timeline | Complete results workspace |
| 5 | Export engine: CSV, JSON, XLSX, JSONL, per-page HTML/Markdown snapshots, export presets | Reusable export packages |
| 6 | Deep extraction: images, scripts, CSS, documents/PDF, headings, structured data, forms, link attributes | Broad website inventory |
| 7 | Technical/SEO analysis: status and redirect chains, broken links, title/meta, canonicals, robots directives, duplicates, orphan-page candidates | Technical audit reports |
| 8 | Visual analytics: site graph, depth map, internal-link graph, status distribution, crawl comparison | Interactive visual workspace |
| 9 | Advanced browser evaluation: session profiles, manual login handoff, cookies, shadow DOM/open roots, iframe inventory, alternative wait strategies | Authorised authenticated/browser crawl |
| 10 | Scale and resilience: per-host throttling, adaptive concurrency, retry budgets, cache/conditional requests, resource budgets, checkpointing | Stable larger-site crawling |
| 11 | Extensibility and automation: custom extraction rules, plugins, schedules, webhooks, CLI, API tokens | Customisable crawler platform |
| 12 | Packaging and deployment: signed Windows package, portable mode, Ubuntu service mode, backup/restore, upgrade path | Distributable local/self-hosted product |

Stages are sequential by dependency, but some UI and test work can be developed in parallel. A stage is not complete until its acceptance tests pass.
