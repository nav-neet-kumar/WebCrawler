# Changelog

## 0.1.0 — Stage 1 foundation

- Added local React dashboard and Fastify API.
- Added Crawlee queue-based recursive same-origin crawling.
- Added HTTP-first fetching and Playwright fallback.
- Added URL de-duplication, depth/page/concurrency limits, and robots.txt respect.
- Added basic metadata, text and link extraction.
- Added per-method attempt history and fallback reasons.
- Added local-target restrictions and cross-origin redirect controls.
- Added initial unit tests and 12-stage technical roadmap.
