import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';

type CrawlStatus = 'queued' | 'running' | 'stopping' | 'completed' | 'stopped' | 'failed';
type FetchMethod = 'http' | 'playwright' | 'none';
interface FetchAttempt {
  method: string;
  outcome: string;
  statusCode?: number;
  durationMs: number;
  message?: string;
}
interface CrawlPage {
  url: string;
  finalUrl?: string;
  statusCode?: number;
  contentType?: string;
  title?: string;
  description?: string;
  h1?: string[];
  wordCount: number;
  internalLinks: number;
  externalLinks: number;
  fetchMethod: FetchMethod;
  attempts: FetchAttempt[];
  fallbackReason?: string;
  depth: number;
  durationMs: number;
  outcome: string;
  error?: string;
  crawledAt: string;
}
interface Crawl {
  id: string;
  status: CrawlStatus;
  options: { startUrl: string; maxPages: number; maxDepth: number; concurrency: number };
  startedAt: string;
  finishedAt?: string;
  stats: {
    discovered: number;
    processed: number;
    succeeded: number;
    failed: number;
    browserFallbacks: number;
    internalLinksFound: number;
    externalLinksFound: number;
  };
  pages: CrawlPage[];
  logs: Array<{ at: string; level: string; message: string; url?: string }>;
  error?: string;
}

const fmtTime = (value: string) => new Date(value).toLocaleTimeString();
const fmtNumber = (value: number) => new Intl.NumberFormat().format(value);

export default function App() {
  const [url, setUrl] = useState('https://example.com/');
  const [maxPages, setMaxPages] = useState(500);
  const [maxDepth, setMaxDepth] = useState(5);
  const [concurrency, setConcurrency] = useState(3);
  const [crawl, setCrawl] = useState<Crawl | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [tab, setTab] = useState<'pages' | 'logs'>('pages');

  const refresh = useCallback(async (id: string) => {
    try {
      const response = await fetch(`/api/crawls/${id}`);
      if (!response.ok) return;
      const data = (await response.json()) as { crawl: Crawl };
      setCrawl(data.crawl);
    } catch {
      // Polling is best-effort; a later poll will retry automatically.
    }
  }, []);

  useEffect(() => {
    if (!crawl || !['queued', 'running', 'stopping'].includes(crawl.status)) return;
    const timer = window.setInterval(() => void refresh(crawl.id), 1000);
    return () => window.clearInterval(timer);
  }, [crawl?.id, crawl?.status, refresh]);

  const start = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await fetch('/api/crawls', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ url, maxPages, maxDepth, concurrency }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? 'Unable to start crawl.');
      setCrawl(data.crawl as Crawl);
      setTab('pages');
      setSearch('');
      setFilter('all');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setLoading(false);
    }
  };

  const stop = async () => {
    if (!crawl) return;
    setError('');
    try {
      const response = await fetch(`/api/crawls/${crawl.id}/stop`, { method: 'POST' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? 'Unable to stop crawl.');
      setCrawl(data.crawl as Crawl);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  };

  const filteredPages = useMemo(() => {
    if (!crawl) return [];
    const query = search.trim().toLowerCase();
    return crawl.pages.filter((page) => {
      const matchesSearch = !query || [page.url, page.title ?? '', page.contentType ?? '', page.error ?? ''].some((v) => v.toLowerCase().includes(query));
      const matchesFilter = filter === 'all' ||
        (filter === 'errors' && ['http-error', 'blocked', 'failed'].includes(page.outcome)) ||
        (filter === 'browser' && page.fetchMethod === 'playwright') ||
        (filter === 'http' && page.fetchMethod === 'http');
      return matchesSearch && matchesFilter;
    }).slice().reverse();
  }, [crawl, filter, search]);

  const progress = crawl ? (crawl.status === 'completed' ? 100 : Math.min(99, Math.round((crawl.stats.processed / Math.max(1, crawl.stats.discovered)) * 100))) : 0;
  const active = crawl && ['queued', 'running', 'stopping'].includes(crawl.status);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><span>W</span></div>
          <div><strong>WebCrawler</strong><small>LOCAL WEBSITE DISCOVERY</small></div>
        </div>
        <div className="topbar-right"><span className="local-dot" /> LOCAL ENGINE <span className="version">v0.1.0 · Stage 1</span></div>
      </header>

      <main className="main-content">
        <section className="hero-row">
          <div>
            <p className="eyebrow">HYBRID CRAWL WORKSPACE</p>
            <h1>Discover what’s inside a website.</h1>
            <p className="subhead">HTTP-first crawling with browser rendering as a fallback.</p>
          </div>
          <div className="engine-pill"><span className="pulse" /> CRAWLEE + PLAYWRIGHT</div>
        </section>

        <section className="panel config-panel">
          <div className="section-heading">
            <div><span className="step-index">01</span><h2>New crawl</h2></div>
            <span className="muted-label">SAME-ORIGIN SCOPE · ROBOTS.TXT RESPECTED</span>
          </div>
          <form onSubmit={start}>
            <label className="field-label" htmlFor="target-url">Target website</label>
            <div className="url-input-wrap"><span className="url-icon">↗</span><input id="target-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com" type="url" required /></div>
            <div className="config-grid">
              <label><span>Maximum pages</span><input type="number" min={1} max={10000} value={maxPages} onChange={(e) => setMaxPages(Number(e.target.value))} /></label>
              <label><span>Maximum depth</span><input type="number" min={0} max={20} value={maxDepth} onChange={(e) => setMaxDepth(Number(e.target.value))} /></label>
              <label><span>Concurrency</span><input type="number" min={1} max={8} value={concurrency} onChange={(e) => setConcurrency(Number(e.target.value))} /></label>
              <div className="mode-control"><span>Crawl strategy</span><div className="mode-value"><span className="mode-dot" /> Hybrid <small>HTTP → Browser fallback</small></div></div>
            </div>
            <div className="form-footer">
              <p className="helper-text">Public HTTP/HTTPS targets only. Pages blocked by access controls or rate limits are reported, not bypassed.</p>
              <button className="primary-button" type="submit" disabled={loading || !!active}><span>{loading ? 'Starting…' : '▶  Start crawl'}</span></button>
            </div>
          </form>
          {error && <div className="error-banner">{error}</div>}
        </section>

        {crawl ? (
          <>
            <section className="run-heading">
              <div><p className="eyebrow">CURRENT CRAWL</p><h2>{new URL(crawl.options.startUrl).hostname}</h2><p className="crawl-url">{crawl.options.startUrl}</p></div>
              <div className={`status-chip ${crawl.status}`}><span /> {crawl.status}</div>
            </section>

            <section className="stats-grid">
              <Stat label="URLs discovered" value={fmtNumber(crawl.stats.discovered)} icon="◎" />
              <Stat label="Pages evaluated" value={fmtNumber(crawl.stats.processed)} icon="▤" />
              <Stat label="Successful" value={fmtNumber(crawl.stats.succeeded)} icon="✓" />
              <Stat label="Errors / blocked" value={fmtNumber(crawl.stats.failed)} icon="!" />
              <Stat label="Browser fallbacks" value={fmtNumber(crawl.stats.browserFallbacks)} icon="◉" />
            </section>

            <section className="panel progress-panel">
              <div className="progress-heading"><div><strong>Discovery progress</strong><span>{fmtNumber(crawl.stats.processed)} evaluated · {fmtNumber(crawl.stats.discovered)} discovered</span></div><strong>{progress}%</strong></div>
              <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
              <div className="progress-footer"><span>Started {fmtTime(crawl.startedAt)}</span><span>{crawl.finishedAt ? `Finished ${fmtTime(crawl.finishedAt)}` : 'Live crawl'}</span><span>{crawl.stats.internalLinksFound} internal links · {crawl.stats.externalLinksFound} external links</span></div>
              {active && <div className="stop-row"><span>Jobs run locally on this computer.</span><button className="stop-button" onClick={() => void stop()}>Stop crawl</button></div>}
              {crawl.error && <div className="error-banner">{crawl.error}</div>}
            </section>

            <section className="panel results-panel">
              <div className="results-header">
                <div className="tabs"><button className={tab === 'pages' ? 'active' : ''} onClick={() => setTab('pages')}>Pages <span>{crawl.pages.length}</span></button><button className={tab === 'logs' ? 'active' : ''} onClick={() => setTab('logs')}>Activity log <span>{crawl.logs.length}</span></button></div>
                {tab === 'pages' && <div className="table-tools"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter URLs or titles…" /><select value={filter} onChange={(e) => setFilter(e.target.value)}><option value="all">All results</option><option value="errors">Errors / blocked</option><option value="http">HTTP</option><option value="browser">Browser fallback</option></select></div>}
              </div>
              {tab === 'pages' ? (
                <div className="table-scroll"><table><thead><tr><th>PAGE</th><th>STATUS</th><th>METHOD</th><th>DEPTH</th><th>LINKS</th><th>WORDS</th><th>TIME</th></tr></thead><tbody>
                  {filteredPages.map((page) => <tr key={`${page.url}-${page.crawledAt}`}>
                    <td className="page-cell"><a href={page.url} target="_blank" rel="noreferrer">{page.title || page.url}</a><small>{page.url}</small>{page.fallbackReason && <small className="fallback-reason">Fallback: {page.fallbackReason}</small>}{page.error && <small className="row-error">{page.error}</small>}<details className="attempt-details"><summary>{page.attempts.length} attempt{page.attempts.length === 1 ? '' : 's'} · details</summary><div>{page.attempts.map((attempt, index) => <p key={index}><b>{attempt.method}</b> — {attempt.outcome}{attempt.statusCode ? ` · HTTP ${attempt.statusCode}` : ''} · {attempt.durationMs} ms{attempt.message ? ` · ${attempt.message}` : ''}</p>)}</div></details></td>
                    <td><span className={`http-code ${page.statusCode && page.statusCode < 400 ? 'good' : 'bad'}`}>{page.statusCode ?? '—'}</span></td>
                    <td><span className={`method-tag ${page.fetchMethod}`}>{page.fetchMethod === 'http' ? 'HTTP' : page.fetchMethod === 'playwright' ? 'BROWSER' : 'NONE'}</span></td>
                    <td>{page.depth}</td><td>{page.internalLinks} in / {page.externalLinks} out</td><td>{fmtNumber(page.wordCount)}</td><td>{page.durationMs} ms</td>
                  </tr>)}
                  {filteredPages.length === 0 && <tr><td colSpan={7} className="empty-state">No pages match this filter yet.</td></tr>}
                </tbody></table></div>
              ) : (
                <div className="logs-list">{crawl.logs.slice().reverse().map((log, index) => <div className="log-line" key={`${log.at}-${index}`}><time>{fmtTime(log.at)}</time><span className={`log-level ${log.level}`}>{log.level}</span><div><p>{log.message}</p>{log.url && <small>{log.url}</small>}</div></div>)}</div>
              )}
            </section>
          </>
        ) : (
          <section className="empty-workspace"><div className="empty-icon">⌁</div><h2>Your crawl workspace is ready</h2><p>Enter a public website above to discover its linked pages. Results will appear here in real time.</p><div className="empty-points"><span>✓ URL deduplication</span><span>✓ HTTP + browser fallback</span><span>✓ robots.txt respect</span><span>✓ Crawl depth and page limits</span></div></section>
        )}
      </main>
      <footer className="footer"><span>WEBCRAWLER · LOCAL-FIRST</span><span>Stage 1: discovery engine foundation</span></footer>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: string }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><i>{icon}</i></div><strong>{value}</strong></div>;
}
